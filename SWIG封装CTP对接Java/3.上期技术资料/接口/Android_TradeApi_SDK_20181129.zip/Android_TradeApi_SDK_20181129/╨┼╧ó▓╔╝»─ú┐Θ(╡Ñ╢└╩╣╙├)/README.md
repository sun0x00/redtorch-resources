# 1. 说明

文件名称：InfoCollection_single_release_v1.3-2018-11-29.aar

该文件仅适用于单独采集信息的情景。

# 2. 开发环境要求

开发者需要配置Kotlin开发环境，否则采集模块可能无法正常使用。


# 3. 应用权限配置

信息采集模块采集信息时，需要应用具备某些权限。若应用不具备某些权限，可能会导致获取到对应的采集项为空。因此在使用信息采集模块前， 请使用者申请权限。

使用到的权限如下(可能会根据需求变动)：
```
​    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE"/>
​    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
​    <uses-permission android:name="android.permission.READ_PHONE_STATE"/>
​    <uses-permission android:name="android.permission.INTERNET"/>
​    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
​    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
```


# 4. 支持

目前SDK支持armeabi结构，不支持x86架构。


